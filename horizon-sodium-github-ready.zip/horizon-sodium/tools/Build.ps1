param(
    [Parameter(Mandatory=$true)][string]$HorizonSource,
    [Parameter(Mandatory=$true)][string]$MixinsCli,
    [string]$WorkDirectory
)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
if(-not $WorkDirectory){$WorkDirectory=Join-Path $projectRoot 'work'}
$sourcePath=(Resolve-Path -LiteralPath $HorizonSource).Path
$toolPath=(Resolve-Path -LiteralPath $MixinsCli).Path
$expected='c9d474dd9116e84c243f8992d75c11314df56f06'
$actual=(& git -C $sourcePath rev-parse HEAD).Trim()
if($LASTEXITCODE -ne 0 -or $actual -ne $expected){throw "Use the exact Horizon revision $expected"}
$mesher=Join-Path $sourcePath 'crates/horizon-client-render/src/mesher.rs'
$hash=(Get-FileHash -LiteralPath $mesher -Algorithm SHA256).Hash.ToLowerInvariant()
if($hash -ne 'f00da3f878b2ba1bd538e0fc7c40a23bb669319e4ddf37bca4bd450a2eb53523'){throw 'Pristine mesher source required.'}
New-Item -ItemType Directory -Force -Path $WorkDirectory | Out-Null
$workRoot=(Resolve-Path -LiteralPath $WorkDirectory).Path
$stage=Join-Path $workRoot ('staged-'+[guid]::NewGuid().ToString('N'))
& $toolPath apply --workspace $sourcePath --mods (Join-Path $projectRoot 'mixins') --out $stage
if($LASTEXITCODE -ne 0){throw 'Native mixin staging failed.'}
& cargo test --manifest-path (Join-Path $stage 'Cargo.toml') -p horizon-client --bin horizon-client --locked sodium_horizon_ui::tests
if($LASTEXITCODE -ne 0){throw 'Game-bound control tests failed.'}
& cargo build --manifest-path (Join-Path $stage 'Cargo.toml') -p horizon-client --bin horizon-client --locked
if($LASTEXITCODE -ne 0){throw 'Native client build failed.'}
Write-Output "Built isolated client from: $stage"
Write-Output 'Default Horizon features, including audio, are enabled. Run games only with isolated test data.'
