"""Create a deterministic Horizon source bundle; does not install or run it."""
from pathlib import Path
import hashlib, json, zipfile

root = Path(__file__).resolve().parents[1]
meta = json.loads((root / 'horizon-native.json').read_text())
dist = root / 'dist'
dist.mkdir(exist_ok=True)
out = dist / f"{meta['id']}-{meta['version']}.hnmod"
files = [root / 'horizon-native.json', *sorted((root / 'mixins').rglob('*'))]
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        if not path.is_file():
            continue
        entry = zipfile.ZipInfo(path.relative_to(root).as_posix(), (2026, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, path.read_bytes())
print(out)
print('SHA256:', hashlib.sha256(out.read_bytes()).hexdigest())
