#[path = "../mixins/sodium_horizon/extra_runtime.rs"]
#[allow(dead_code)]
mod sodium_extra_filters;

#[derive(Clone, Copy, PartialEq, Debug)]
struct Blend {
    frame: usize,
    next: usize,
    millis: u32,
}
struct Animation {
    layer: u32,
}
impl Animation {
    fn blend(&self, tick: u64) -> Blend {
        Blend {
            frame: (tick % 2) as usize,
            next: ((tick + 1) % 2) as usize,
            millis: 250,
        }
    }
}
struct Sprite {
    animation: Animation,
    shown: Option<Blend>,
    layer: u32,
    frames: Vec<u32>,
    edge: u32,
    group: usize,
}
struct Group {
    jobs: Vec<u8>,
}
struct SpriteAnimator {
    sprites: Vec<Sprite>,
    groups: Vec<Group>,
    changed: Vec<u32>,
}
include!("../mixins/sodium_horizon/extra_animations.rs");

#[test]
fn disabled_animations_queue_no_jobs_and_resume_at_the_current_tick() {
    sodium_extra_filters::register_layer(0, "minecraft:block/water_still");
    sodium_extra_filters::register_layer(1, "minecraft:block/lava_still");
    let mut animator = SpriteAnimator {
        sprites: (0..2)
            .map(|layer| Sprite {
                animation: Animation { layer },
                shown: None,
                layer,
                frames: vec![100, 200],
                edge: 16,
                group: 0,
            })
            .collect(),
        groups: vec![Group { jobs: vec![] }],
        changed: vec![],
    };
    sodium_extra_filters::configure(u64::MAX & !1, &[]);
    assert_eq!(
        extra_animations(&mut animator, 0, None),
        std::ops::ControlFlow::Break(1)
    );
    assert_eq!(animator.changed, vec![1]);
    let expected: Vec<u8> = [1u32, 100, 200, 250, 16]
        .into_iter()
        .flat_map(u32::to_le_bytes)
        .collect();
    assert_eq!(animator.groups[0].jobs, expected);
    assert_eq!(animator.sprites[0].shown, None);
    animator.groups[0].jobs.clear();
    sodium_extra_filters::configure(u64::MAX, &[]);
    assert_eq!(
        extra_animations(&mut animator, 1, Some(&[1])),
        std::ops::ControlFlow::Break(1)
    );
    assert_eq!(animator.changed, vec![0]);
    let expected: Vec<u8> = [0u32, 200, 100, 250, 16]
        .into_iter()
        .flat_map(u32::to_le_bytes)
        .collect();
    assert_eq!(animator.groups[0].jobs, expected);
    animator.groups[0].jobs.clear();
    assert_eq!(
        extra_animations(&mut animator, 1, Some(&[1])),
        std::ops::ControlFlow::Break(0)
    );
    assert!(animator.groups[0].jobs.is_empty());
}
