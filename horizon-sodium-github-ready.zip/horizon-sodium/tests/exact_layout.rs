#[path="../mixins/sodium_horizon/exact_model.rs"]
#[allow(dead_code)]
mod model;
use model::*;
#[test]
fn both_distance_sliders_allow_128_chunks(){
 assert_eq!((OPTIONS[0].binding,OPTIONS[0].max),(0,128));
 assert_eq!((OPTIONS[1].binding,OPTIONS[1].max),(1,128));
}
#[test]
fn graphics_api_uses_horizons_native_backend_indices(){
 let api=OPTIONS.iter().find(|o|o.name=="Graphics API").unwrap();
 assert_eq!((api.binding,api.transform,api.min,api.max),(23,0,0,3));
 assert_eq!(api.labels,&[(0,"Auto"),(1,"Vulkan"),(2,"DirectX 12"),(3,"OpenGL")]);
 assert!(api.tooltip.contains("restart Horizon"));
}
#[test]
fn wheel_is_confined_to_the_options_viewport(){
 for (w,h) in [(640.0,360.0),(427.0,240.0),(1280.0,720.0)] {
  let l=Layout::new(w,h);
  assert!(!l.list_contains([l.x+60.0,l.top+70.0]));
  assert!(!l.list_contains([l.list_x()+40.0,l.top-1.0]));
  assert!(!l.list_contains([l.list_x()+40.0,l.bottom]));
  assert!(!l.list_contains([l.list_x()+219.0,l.top+10.0]));
  assert!(l.list_contains([l.list_x(),l.top]));
  assert!(l.list_contains([l.list_x()+218.0,l.bottom-1.0]));
 }
}
#[test]
fn geometry_matches_original_runtime_measurements(){
 let a=Layout::new(640.0,360.0);
 assert_eq!([a.x,a.y,a.width,a.height],[50.0,6.0,540.0,348.0]);
 assert_eq!(a.row(0,0.0),[181.0,76.0,204.0,18.0]);
 assert_eq!(a.button(0),[525.0,334.0,65.0,20.0]);
 assert_eq!(a.button(1),[525.0,309.0,65.0,20.0]);
 let b=Layout::new(427.0,240.0);
 assert_eq!([b.x,b.y,b.width,b.height],[0.0,0.0,427.0,240.0]);
 assert_eq!(b.list_x(),128.0);
 assert_eq!(b.button(0),[357.0,215.0,65.0,20.0]);
 let c=Layout::new(1280.0,720.0);
 assert_eq!([c.x,c.y,c.width,c.height],[362.0,6.0,555.0,708.0]);
 assert_eq!(c.button(0),[852.0,694.0,65.0,20.0]);
}
#[test]
fn original_wording_and_section_anchors_are_preserved(){
 assert_eq!(OPTIONS.len(),241);
 assert_eq!(OPTIONS[2].name,"Brightness");
 assert_eq!(OPTIONS[4].name,"Fullscreen Mode");
 assert_eq!(OPTIONS[30].name,"Chunk Update Threads");
 assert_eq!(OPTIONS[240].name,"Steady Debug HUD Refresh Interval");
 assert_eq!(PAGES,["General","Quality","Performance","Animations","Particles","Details","Render","Extras"]);
 assert_eq!(PAGE_SCROLL[1],252);
 assert_eq!(PAGE_SCROLL[3],840);
}
