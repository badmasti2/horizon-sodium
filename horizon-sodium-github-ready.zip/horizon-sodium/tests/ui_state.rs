#[path = "../mixins/sodium_horizon/ui_model.rs"]
#[allow(dead_code)]
mod model;
use model::*;

#[test]
fn edits_are_staged_undoable_and_committed_only_when_requested() {
    let start: Vec<i32> = SPECS.iter().map(|s| s.min).collect();
    let mut ui = Editor::new(start.clone());
    ui.draft[0] = 16;
    ui.draft[12] = 1;
    assert_eq!(ui.original, start);
    assert_eq!(ui.changed(), vec![0, 12]);
    ui.select_tab(2);
    assert_eq!(ui.draft[0], 16);
    ui.undo();
    assert!(!ui.dirty());
    ui.draft[17] = 4;
    ui.commit();
    assert_eq!(ui.original[17], 4);
    assert!(!ui.dirty());
}

#[test]
fn sliders_and_cycles_have_safe_endpoints() {
    let distance = SPECS[0];
    assert_eq!(distance.slider(-1.0), 2);
    assert_eq!(distance.slider(2.0), 128);
    assert_eq!(distance.slider(0.5), 65);
    assert_eq!(distance.cycle(128, false), 2);
    assert_eq!(distance.cycle(2, true), 128);
    assert_eq!(SPECS[1].slider(1.0), 128);
    let vsync = SPECS[3];
    assert_eq!(vsync.cycle(0, true), 1);
    assert_eq!(vsync.cycle(1, false), 0);
}

#[test]
fn navigation_resets_scroll_and_small_window_controls_stay_visible() {
    let mut ui = Editor::new(vec![0; SPECS.len()]);
    ui.scroll = 4;
    ui.dragging = Some(2);
    ui.select_tab(3);
    assert_eq!(ui.rows(), vec![18, 19, 20, 21, 22, 23]);
    assert_eq!(ui.scroll, 0);
    assert_eq!(ui.dragging, None);
    for (w, h) in [(320.0, 240.0), (640.0, 360.0), (1920.0, 1080.0)] {
        let layout = Layout::new(w, h);
        let last = layout.row(layout.visible - 1);
        assert!(last[1] + last[3] <= layout.bottom);
        let done = layout.button(3);
        assert!(done[0] + done[2] <= w);
        assert!(done[1] + done[3] <= h);
        assert!(hit([done[0] + 1.0, done[1] + 1.0], done));
    }
}

#[test]
fn particle_search_handles_matches_and_an_empty_result_without_changing_values() {
    let mut ui = Editor::new(vec![1; SPECS.len()]);
    ui.select_tab(5);
    ui.filter = "smoke".into();
    assert!(ui.rows().len() >= 4);
    assert!(ui.rows().iter().all(|&i| SPECS[i].key.contains("smoke")));
    ui.filter = "no-such-particle".into();
    assert!(ui.rows().is_empty());
    assert!(!ui.dirty());
    ui.select_tab(4);
    assert_eq!(ui.rows(), vec![24, 25, 26, 27, 28, 29]);
}
