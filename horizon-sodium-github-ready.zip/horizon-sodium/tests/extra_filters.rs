#[path = "../mixins/sodium_horizon/extra_runtime.rs"]
#[allow(dead_code)]
mod filters;

#[test]
fn filters_preserve_defaults_and_independently_disable_requested_work() {
    use filters::*;
    configure(u64::MAX, &[]);
    assert!(particle_allowed(6, false));
    assert!(particle_allowed(6, true));
    register_layer(1, "minecraft:block/water_still");
    register_layer(2, "minecraft:block/lava_flow");
    register_layer(3, "minecraft:block/soul_fire_0");
    register_layer(4, "minecraft:block/nether_portal");
    register_layer(5, "minecraft:block/sculk_sensor_top");
    register_layer(6, "custom:block/animated_machine");
    configure(u64::MAX & !(1 << 0) & !(1 << 7), &[6, 65, 130]);
    assert!(!animation_allowed(1));
    for layer in 2..=6 {
        assert!(animation_allowed(layer));
    }
    assert!(!particle_allowed(6, false));
    assert!(!particle_allowed(65, false));
    assert!(!particle_allowed(130, false));
    assert!(particle_allowed(64, false));
    assert!(!particle_allowed(64, true));
    configure(u64::MAX & !(1 << 6), &[]);
    assert!(!particle_allowed(64, false));
    assert!(!particle_allowed(64, true));
    configure(u64::MAX, &[]);
    assert!(particle_allowed(6, false));
    assert!(animation_allowed(1));
}
