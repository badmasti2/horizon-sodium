extern crate self as horizon_client;
pub mod hud {#[derive(Default)] pub struct HudBatch {pub draws:Vec<([f32;4],u32)>}}
struct Game<'a>(std::marker::PhantomData<&'a ()>);
impl Game<'_>{fn native_fill(&self,b:&mut hud::HudBatch,r:[f32;4],c:u32){b.draws.push((r,c));}}
#[path="../mixins/sodium_horizon/icons.rs"]mod icons;
#[test]fn config_icon_is_transparent_and_uses_the_original_theme_tint(){
 let g=Game(std::marker::PhantomData);let mut b=hud::HudBatch::default();
 icons::draw(&g,&mut b,false,[0.0,0.0],20.0,Some(0xffcafded));
 assert!(b.draws.iter().any(|(_,c)|*c==0xffcafded));
 assert!(b.draws.len()<400);
 let mut e=hud::HudBatch::default();icons::draw(&g,&mut e,true,[0.0,0.0],20.0,Some(0xffd2c0ff));
 assert!(e.draws.iter().any(|(_,c)|*c==0xffd2c0ff));
}
