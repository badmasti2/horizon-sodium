use sodium_horizon_experimental::resolve;

// Independent voxel BFS oracle: intentionally does not use bit-row expansion.
fn reference(open: &[u16; 256]) -> u64 {
    let mut visited = [false; 4096];
    let mut todo = Vec::new();
    let mut matrix = 0;
    for root in 0..4096 {
        if visited[root] || open[root >> 4] & (1 << (root & 15)) == 0 {
            continue;
        }
        visited[root] = true;
        todo.push(root);
        let mut faces = [false; 6];
        while let Some(cell) = todo.pop() {
            let (x, y, z) = (cell & 15, cell >> 8, (cell >> 4) & 15);
            for (i, on) in [y == 0, y == 15, z == 0, z == 15, x == 0, x == 15]
                .into_iter()
                .enumerate()
            {
                faces[i] |= on;
            }
            for (dx, dy, dz) in [
                (1, 0, 0),
                (-1, 0, 0),
                (0, 1, 0),
                (0, -1, 0),
                (0, 0, 1),
                (0, 0, -1),
            ] {
                let (nx, ny, nz) = (x as i32 + dx, y as i32 + dy, z as i32 + dz);
                if !(0..16).contains(&nx) || !(0..16).contains(&ny) || !(0..16).contains(&nz) {
                    continue;
                }
                let n = ((ny << 8) | (nz << 4) | nx) as usize;
                if !visited[n] && open[n >> 4] & (1 << (n & 15)) != 0 {
                    visited[n] = true;
                    todo.push(n);
                }
            }
        }
        for a in 0..6 {
            for b in 0..6 {
                if faces[a] && faces[b] {
                    matrix |= 1 << (a * 6 + b);
                }
            }
        }
    }
    matrix
}

#[test]
fn geometry_and_reused_dirty_scratch() {
    let mut stack = vec![usize::MAX; 123];
    let mut cases = vec![[0; 256], [u16::MAX; 256]];
    let mut cavity = [0; 256];
    cavity[8 * 16 + 8] = 1 << 8;
    cases.push(cavity);
    for axis in 0..3 {
        let mut tunnel = [0; 256];
        for i in 0..16 {
            let (x, y, z) = match axis {
                0 => (i, 8, 8),
                1 => (8, i, 8),
                _ => (8, 8, i),
            };
            tunnel[y * 16 + z] |= 1 << x;
        }
        cases.push(tunnel);
        let mut wall = [u16::MAX; 256];
        for y in 0..16 {
            for z in 0..16 {
                for x in 0..16 {
                    if [x, y, z][axis] == 8 {
                        wall[y * 16 + z] &= !(1 << x);
                    }
                }
            }
        }
        cases.push(wall);
    }
    for (i, case) in cases.iter().enumerate() {
        assert_eq!(resolve(case, &mut stack), reference(case), "fixture {i}");
        assert!(stack.is_empty());
    }
}

#[test]
fn every_single_boundary_cell() {
    let mut stack = Vec::new();
    for cell in 0..4096 {
        let mut open = [0; 256];
        open[cell >> 4] = 1 << (cell & 15);
        assert_eq!(resolve(&open, &mut stack), reference(&open), "cell {cell}");
    }
}

#[test]
fn deterministic_random_sections() {
    let mut seed = 0x9781_2ac3_465b_10deu64;
    let mut stack = Vec::new();
    for threshold in [1u64, 10, 25, 50, 75, 90, 99] {
        for sample in 0..200 {
            let mut open = [0; 256];
            for cell in 0..4096 {
                seed ^= seed << 13;
                seed ^= seed >> 7;
                seed ^= seed << 17;
                if seed % 100 < threshold {
                    open[cell >> 4] |= 1 << (cell & 15);
                }
            }
            assert_eq!(
                resolve(&open, &mut stack),
                reference(&open),
                "density {threshold}, sample {sample}"
            );
        }
    }
}

#[test]
fn all_small_embedded_patterns() {
    let mut stack = Vec::new();
    for origin in [(0, 0, 0), (7, 7, 7), (14, 14, 14)] {
        for pattern in 0..256u16 {
            let mut open = [0; 256];
            for bit in 0..8 {
                if pattern & (1 << bit) != 0 {
                    let (x, y, z) = (
                        origin.0 + (bit & 1),
                        origin.1 + (bit >> 2),
                        origin.2 + ((bit >> 1) & 1),
                    );
                    open[y * 16 + z] |= 1 << x;
                }
            }
            assert_eq!(resolve(&open, &mut stack), reference(&open));
        }
    }
}
