---
name: Bug report
about: Report a build failure, UI problem or rendering issue
title: ""
labels: ""
assignees: ""
---

**What happened?**

**What did you expect?**

**Steps to reproduce**
1.
2.
3.

**Versions**
- Horizon revision:
- Mod version:
- Operating system and GPU:
- Graphics API:
- Other native mods:

**Relevant log or screenshot**
For native builds, include the first error from the launcher's native build log. Remove private information before posting.
