## Change

Describe the problem and resulting behavior.

## Validation

- [ ] Standalone tests pass.
- [ ] Bundle packages successfully.
- [ ] Native hook changes compile against the pinned revision, or the limitation is explained.

List relevant screenshots and any remaining limitations.
